-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 192.168.1.137    Database: Policies
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.9-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `Policies`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Policies` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `Policies`;

--
-- Table structure for table `Authors_Join`
--

DROP TABLE IF EXISTS `Authors_Join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Authors_Join` (
  `author_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `chapter_id` int(10) unsigned NOT NULL,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`author_id`),
  KEY `user_id` (`user_id`),
  KEY `document_id` (`document_id`),
  KEY `chapter_id` (`chapter_id`),
  CONSTRAINT `Authors_Join_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `Organizations`.`Users` (`user_id`),
  CONSTRAINT `Authors_Join_ibfk_2` FOREIGN KEY (`chapter_id`) REFERENCES `Chapters` (`chapter_id`),
  CONSTRAINT `Authors_Join_ibfk_3` FOREIGN KEY (`document_id`) REFERENCES `Documents` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Authors_Join`
--

LOCK TABLES `Authors_Join` WRITE;
/*!40000 ALTER TABLE `Authors_Join` DISABLE KEYS */;
/*!40000 ALTER TABLE `Authors_Join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Chapter_Regulation_Join`
--

DROP TABLE IF EXISTS `Chapter_Regulation_Join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Chapter_Regulation_Join` (
  `_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `regulation_id` int(10) unsigned DEFAULT NULL,
  `chapter_id` int(10) unsigned DEFAULT NULL,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`_id`),
  KEY `regulation_id` (`regulation_id`),
  KEY `chapter_id` (`chapter_id`),
  CONSTRAINT `Chapter_Regulation_Join_ibfk_1` FOREIGN KEY (`regulation_id`) REFERENCES `Regulations` (`regulation_id`),
  CONSTRAINT `Chapter_Regulation_Join_ibfk_2` FOREIGN KEY (`chapter_id`) REFERENCES `Chapters` (`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Chapter_Regulation_Join`
--

LOCK TABLES `Chapter_Regulation_Join` WRITE;
/*!40000 ALTER TABLE `Chapter_Regulation_Join` DISABLE KEYS */;
/*!40000 ALTER TABLE `Chapter_Regulation_Join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Chapter_Sections`
--

DROP TABLE IF EXISTS `Chapter_Sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Chapter_Sections` (
  `section_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chapter_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`section_id`),
  KEY `chapter_id` (`chapter_id`),
  CONSTRAINT `Chapter_Sections_ibfk_1` FOREIGN KEY (`chapter_id`) REFERENCES `Chapters` (`chapter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Chapter_Sections`
--

LOCK TABLES `Chapter_Sections` WRITE;
/*!40000 ALTER TABLE `Chapter_Sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `Chapter_Sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Chapters`
--

DROP TABLE IF EXISTS `Chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Chapters` (
  `chapter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `revision` int(10) unsigned DEFAULT 1,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`chapter_id`),
  KEY `document_id` (`document_id`),
  CONSTRAINT `Chapters_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `Documents` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Chapters`
--

LOCK TABLES `Chapters` WRITE;
/*!40000 ALTER TABLE `Chapters` DISABLE KEYS */;
/*!40000 ALTER TABLE `Chapters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Documents`
--

DROP TABLE IF EXISTS `Documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Documents` (
  `document_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `abv` varchar(8) DEFAULT NULL,
  `revision` int(10) unsigned DEFAULT 1,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Documents`
--

LOCK TABLES `Documents` WRITE;
/*!40000 ALTER TABLE `Documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `Documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Regulations`
--

DROP TABLE IF EXISTS `Regulations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Regulations` (
  `regulation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unique_regulation` varchar(255) NOT NULL DEFAULT concat(`regulation_date`,'-',`title`,'-',`section`),
  `title` varchar(8) NOT NULL,
  `chapter` varchar(8) DEFAULT NULL,
  `subchapter` varchar(8) DEFAULT NULL,
  `part` varchar(8) DEFAULT NULL,
  `subpart` varchar(8) DEFAULT NULL,
  `regulation_date` varchar(16) NOT NULL,
  `section` varchar(8) NOT NULL,
  `timestamp_entered` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `timestamp_modified` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`regulation_id`),
  UNIQUE KEY `unique_regulation` (`unique_regulation`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Regulations`
--

LOCK TABLES `Regulations` WRITE;
/*!40000 ALTER TABLE `Regulations` DISABLE KEYS */;
/*!40000 ALTER TABLE `Regulations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'Policies'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-30 21:15:06
